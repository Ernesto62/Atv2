ID:{{$editora->ide}}<br>
Título:{{$editora->nome}}<br>
Idioma:{{$editora->morada}}