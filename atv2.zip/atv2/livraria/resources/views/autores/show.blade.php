ID:{{$autor->ida}}<br>
Título:{{$autor->nome}}<br>
Idioma:{{$autor->nacionalidade}}