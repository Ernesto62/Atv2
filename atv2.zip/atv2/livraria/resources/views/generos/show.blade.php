ID:{{$genero->idg}}<br>
Título:{{$genero->designacao}}<br>
Idioma:{{$genero->observacoes}}